app.controller('MainController', function ($scope, $location, $anchorScroll, $window, myService) {
  
	$scope.user = {};
	$scope.cost = {};
	$scope.category={};	
	$scope.remark={};
		$scope.music={};
		$scope.managementdetails={};
		$scope.restaurant_data={ "X-API-KEY":'adasdasdasdasdasdasd'
		};
		$scope.formObjects=[];
		
		$scope.user.selling=[];
  $scope.user.special_dish=[];
  $scope.user.target_audience=[];
  $scope.key=1;
		 if(localStorage.getItem('restaurant_data'))
		 {
			 
			$scope.formObjects=JSON.parse($window.localStorage.getItem('restaurant_data'));
			var key=$scope.formObjects[$scope.formObjects.length-1].key;
			
		 }
		// var local_data=$window.localStorage.getItem('restaurant_data');
		// local_data=JSON.parse(local_data);
		// $scope.local_data=local_data;
		// console.log(local_data);
		// $scope.form=[];
	// $scope.detail = {
	// name : '',
	// address : ''
	// pin_code : ''
	// lat : ''
	// long : ''
	// city : ''
	// state : ''
	// country : ''
	// primary_phone : ''
	// secondary_phone : ''
	// email : ''
	// opening_time : ''
	// closing_time : ''
	// covered_area : ''
	// open_area : ''
	// vegetarian : ''
	// nonvegetarian : ''
	// projector : ''
	// lcd_led : ''
	// maximum_occupancy :
	// target_audience : [],
	// selling : [],
	// special_dish : []
	// };
  
  
	

	$scope.form_onedata = function () {
		var data=localStorage.getItem('restaurant_data');
		 angular.forEach(data, function(value, key)
		 {  if(value.key==$scope.key)
			 $scope.restaurant_data.restaurant_detail=$scope.user;
		 });
		$scope.restaurant_data.restaurant_detail=$scope.user;
		 $scope.formObjects.push( { data:$scope.restaurant_data,
		 key: $scope.key});
		$window.localStorage && $window.localStorage.setItem('restaurant_data', JSON.stringify($scope.formObjects));

	}

	
	$scope.cost.buffet_type =[];
$scope.cost.happy_hours_day={
	1: "",
    2: "",
    3: "",
    4: "",
    5: "",
    6: "",
    7: ""
};
	

	$scope.cost.buffet_opening_time = ['00:00', '00:00', '00:00'];
	$scope.cost.buffet_closing_time = ['00:00', '00:00', '00:00'];
	$scope.cost.buffet_price = ['', '', ''];
	$scope.cost.happy_hours_time = {
		1:{
			start : '00:00',
			end : '00:00'
		},
		2:{
			start : '00:00',
			end : '00:00'
		},
		3:{
			start : '00:00',
			end : '00:00'
		},
		4:{
			start : '00:00',
			end : '00:00'
		},
		5:{
			start : '00:00',
			end : '00:00'
		},
		6:{
			start : '00:00',
			end : '00:00'
		},
		7:{
			start : '00:00',
			end : '00:00'
		},
		};
	
	$scope.cost.offer_value={
    1:{
	  offer1: "",
      offer_code1: "xyz",
      offer2: "",
      offer_code2: "abc"
		
	},
	2:{
	  offer1: "",
      offer_code1: "xyz",
      offer2: "",
      offer_code2: "abc"
		
	},
	3:{
	  offer1: "",
      offer_code1: "xyz",
      offer2: "",
      offer_code2: "abc"
		
	},
	4:{
	  offer1: "",
      offer_code1: "xyz",
      offer2: "",
      offer_code2: "abc"
		
	},
	5:{
	  offer1: "",
      offer_code1: "xyz",
      offer2: "",
      offer_code2: "abc"
		
	},
	6:{
	  offer1: "",
      offer_code1: "xyz",
      offer2: "",
      offer_code2: "abc"
		
	},
	7:{
	  offer1: "",
      offer_code1: "xyz",
      offer2: "",
      offer_code2: "abc"
		
	}
	};
	
	$scope.cost.offer_day=[""];
	$scope.cost.private = [{
			"private_drink" : "1",
			"private_snacks" : "1",
			"dinner" : true,
			"private_main_course" : "1",
			"price" : ""

		}
	];
	

	$scope.addPartyDetails = function () {
		$scope.cost.private.push({
			"private_drink" : "1",
			"private_snacks" : "1",
			"dinner" : "1",
			"private_main_course" : "1",
			"price" : ""
		});

	};

	$scope.form_onedata1 = function () {
		$scope.restaurant_data.restaurant_cost=$scope.cost;
		$window.localStorage && $window.localStorage.setItem('restaurant_data', JSON.stringify($scope.restaurant_data));

	}

	
	
	$scope.managementdetails.management=[
   {
	   name:"",
	   phoneNo:"",
	   designation:"",
	   email:"",
	  
	   
   }
  ];
  
  $scope.addInputItem = function() {
     $scope.managementdetails.management.push( {
	   name:"",
	   mobile:"",
	   designation:"",
	   email:"",
	  
	   
   });
	  
  };
  
  $scope.removeField = function(id)
    {
       // var div = $("#remove"+id);
       // div.remove();
	   var tmpArray = [];
	   for(var i=0;i<$scope.management.length;i++){
		   if(i != id){
			   tmpArray.push($scope.management[i]);
		   }
	   }
	   $scope.management = tmpArray;
    } 
	
	$scope.saveFormaManagement = function(){
		$scope.restaurant_data.restaurant_management=$scope.managementdetails;
	$window.localStorage && $window.localStorage.setItem('restaurant_data', JSON.stringify($scope.restaurant_data));
	}
	
	
	
$scope.category.establishment=[];
$scope.category.cuisine=[];
$scope.category.ambience=[];
$scope.category.highlights=[{
	highlight:""
}];


$scope.addInputItemcat = function() {
     $scope.category.highlights.push({
	highlight:""
});
};

$scope.removeFieldcat = function(id)
    {
       // var div = $("#remove"+id);
       // div.remove();
	   var tmpArray = [];
	   for(var i=0;i<$scope.category.highlights.length;i++){
		   if(i != id){
			   tmpArray.push($scope.category.highlights[i]);
		   }
	   }
	   $scope.category.highlights = tmpArray;
    } 
	

$scope.saveFormcategory = function(){
		$scope.restaurant_data.restaurant_category=$scope.category;
	$window.localStorage && $window.localStorage.setItem('restaurant_data', JSON.stringify($scope.restaurant_data));
	}
	
	
	
	$scope.extraDetails={};
	
	$scope.extraDetails.suggest_parking=[];
	$scope.saveFormExtera = function(){
		$scope.restaurant_data.restaurant_extra=$scope.extraDetails;
	$window.localStorage && $window.localStorage.setItem('restaurant_data', JSON.stringify($scope.restaurant_data));
	}
	

	
$scope.music.Adetails=[
   {
	    name:"",
	   phone:"",
	   email:"",
	   music:"",
	  days:[]
   }
  ];
  
  $scope.addArtist = function() {
     $scope.music.Adetails.push(  {
	   name:"",
	   phone:"",
	   email:"",
	   music:"",
	  days:[]
	  
	   
   });
	  
  };
	
	$scope.music_time=
		[ "", {
			  start: '00:00',
              end: '00:00',
              decibel: "1"
		}
		
		]
		
	
	
$scope.music.music_day=[ , ];
	$scope.saveFormmusic = function(){
		$scope.restaurant_data.restaurant_music=$scope.music;
	$window.localStorage && $window.localStorage.setItem('restaurant_data', JSON.stringify($scope.restaurant_data));
	}
	
	
	$scope.saveFormRemark = function(){
		$scope.restaurant_data.restaurant_remark=$scope.remark;
	$window.localStorage && $window.localStorage.setItem('restaurant_data', JSON.stringify($scope.restaurant_data));
	}
	
	
	
	
	if(localStorage.getItem('restaurant_data')){
		
		
$scope.restaurant_data=JSON.parse(localStorage.getItem('restaurant_data'));
$scope.user=$scope.restaurant_data.restaurant_detail;

 
$scope.cost=$scope.restaurant_data.restaurant_cost;

 
$scope.managementdetails=$scope.restaurant_data.restaurant_management;
 

$scope.category=$scope.restaurant_data.restaurant_category;


$scope.music=$scope.restaurant_data.restaurant_music;


$scope.extraDetails=$scope.restaurant_data.restaurant_extra;



$scope.remark=$scope.restaurant_data.restaurant_remark;

}

	
	
	 console.log($scope.restaurant_data);
		
	
	$scope.uploadData=function()
	 {
	$scope.restaurant_data=	JSON.parse($window.localStorage && $window.localStorage.getItem('restaurant_data')); 
	
	if(!$scope.restaurant_data.restaurant_detail)
	{
		alert("please fill complete data");
	}
	else if(!$scope.restaurant_data.restaurant_cost)
	{
		alert("please fill complete data");
	}
	else if(!$scope.restaurant_data.restaurant_management)
	{
		alert("please fill complete data");
	}
	else if(!$scope.restaurant_data.restaurant_category)
	{
		alert("please fill complete data");
	}
	else if(!$scope.restaurant_data.restaurant_music)
	{
		alert("please fill complete data");
	}
		else if(!$scope.restaurant_data.restaurant_extra)
	{
		alert("please fill complete data");
	}
		else if(!$scope.restaurant_data.restaurant_remark)
	{
		alert("please fill complete data");
	}
	else
	{
	
	  var parameters = {};	
	  parameters.method = 'POST';
	 parameters.url = "http://mywoobly.com/new_webadmin/api/tablet/save";
	 parameters.data= JSON.stringify($scope.restaurant_data);
	
	
	  parameters.onsucess = function (data) {
		   if (data) {
		
			 $window.localStorage && $window.localStorage.removeItem('restaurant_data');
			 
				 	 alert("Data submitted"); 
		 }
	  };
	  parameters.onError = function (e) {
		 alert("Network Error");
	};

	   myService.sendRequest(parameters);
	}
	 }

});

app.controller('addController', function ($scope, $location, $anchorScroll, $window, myService) {
	$scope.addResto=function()
	{   
	
		
	}
	
});

	
	
	
	
	
	
	
	

